/**
 * Attendance — ported from preview/attendance-preview.jsx (approved by
 * Sophia over many rounds — see that file's header for the full behavior
 * spec). This is the real, Supabase-wired version: no mock data, no local
 * seed roster — everything comes from the real `srList` / `branchMeta`
 * props (same ones every other tab in this app already receives) plus
 * this tab's own storage for attendance records, business hours, and
 * attendance-only staff.
 *
 * Props (all optional except where noted):
 *   branchMeta      — the REAL branchMeta object (all retail branches),
 *                      same shape App.jsx/BossViewer/BranchViewer already
 *                      load from Supabase (name, manager, managerId, ...).
 *   srList          — the REAL, company-wide SR list (every branch, not
 *                      just one) — same DEFAULT_SR-shaped array every
 *                      other tab uses.
 *   isAdmin         — true = can fill in attendance / add staff (emaxhr
 *                      or Sophia). false = read-only.
 *   canManageHours  — true only for Sophia — shows the extra
 *                      "Business Hours & Staff" sub-tab. No effect if
 *                      isAdmin is false.
 *   userBranch      — set to a branch code to lock the view to ONE branch
 *                      with no branch picker (a real branch login). Leave
 *                      null for HR/Sophia/cross-branch views.
 *   allowBranchSwitch — when isAdmin is false and userBranch is null, this
 *                      controls whether a branch picker is shown (Boon
 *                      Theng / Wingfei) vs a single fixed branch.
 *   email           — current signed-in email, for attribution only.
 *
 * Storage (Supabase-backed via storage/index.js loadData/saveData, same
 * key-value convention as the rest of the app):
 *   emax_v5_attendance_${year}_${month}  — {personId:{day:entry}}
 *   emax_v5_business_hours               — {branchCode:{start,end}}
 *   emax_v5_attendance_extra_staff       — {branchCode:[{id,name,role,branch}]}
 */
import {useState,useEffect,useMemo} from "react";
import {loadData,saveData} from "./storage/index.js";

/* ── Design tokens — same constants every other tab file in this project
   defines locally (see WarrantyTab.jsx / ChaileaseTab.jsx / StockWriteOffTab.jsx). */
const C={navy:"#0A1628",navyLight:"#162B52",blue:"#1B3F72",blueBright:"#2C5AA0",white:"#fff",surface:"#F7F9FC",border:"#E4EAF2",text:"#0A1628",textMid:"#4A5568",textLight:"#8A96A8",green:"#15803D",amber:"#B45309",red:"#DC2626"};
const card={background:C.white,border:`1px solid ${C.border}`,borderRadius:12,boxShadow:"0 1px 3px rgba(10,22,40,.06),0 4px 12px rgba(10,22,40,.04)",overflow:"hidden"};
const L=({children,req})=><label style={{display:"block",fontSize:11,fontWeight:600,color:C.textMid,marginBottom:4}}>{children}{req&&<span style={{color:C.red}}> *</span>}</label>;
const I=props=><input {...props} style={{width:"100%",padding:"8px 10px",border:`1px solid ${C.border}`,borderRadius:8,fontSize:13,fontFamily:"Inter,sans-serif",boxSizing:"border-box",...(props.style||{})}}/>;
const SEL=props=><select {...props} style={{width:"100%",padding:"8px 10px",border:`1px solid ${C.border}`,borderRadius:8,fontSize:13,fontFamily:"Inter,sans-serif",background:"#fff",boxSizing:"border-box",...(props.style||{})}}/>;
const PBtn=({children,disabled,...p})=><button disabled={disabled} {...p} style={{display:"inline-flex",alignItems:"center",justifyContent:"center",gap:6,padding:"9px 16px",background:disabled?"#E4EAF2":`linear-gradient(135deg,${C.blue},${C.blueBright})`,color:disabled?C.textLight:"#fff",border:"none",borderRadius:8,fontSize:12,fontWeight:700,cursor:disabled?"default":"pointer",fontFamily:"Inter,sans-serif",...(p.style||{})}}>{children}</button>;
const GBtn=({children,...p})=><button {...p} style={{display:"inline-flex",alignItems:"center",gap:6,padding:"8px 14px",background:"transparent",color:C.textMid,border:`1px solid ${C.border}`,borderRadius:8,fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"Inter,sans-serif",...(p.style||{})}}>{children}</button>;

const Ic={
  check:<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>,
  plus:<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
};

/* ── Leave / day-type options (used instead of clock in/out) ─────────── */
const LEAVE_TYPES=[
  {code:"AL",label:"Annual Leave",color:"#2C5AA0"},
  {code:"AH",label:"Annual Leave (Half Day)",color:"#6A9BD8"},
  {code:"SL",label:"Sick Leave",color:"#B45309"},
  {code:"RL",label:"Replacement Leave",color:"#0E7490"},
  {code:"UL",label:"Unpaid Leave (Full Day)",color:"#DC2626"},
  {code:"UH",label:"Unpaid Leave (Half Day)",color:"#EA580C"},
  {code:"OFF",label:"Off Day",color:"#6B7280"},
  {code:"PH",label:"Public Holiday",color:"#7C3AED"},
];
// Half-day leave codes — a half day counts as 0.5 toward that leave type
// AND 0.5 toward Working Days, and is never checked against Business Hours
// (no late / early-out possible on a half-day leave entry).
const HALF_DAY_LEAVE_CODES=["AH","UH"];
const leaveMeta=code=>LEAVE_TYPES.find(l=>l.code===code);

/* ── Branch groups. RETAIL_BRANCHES mirrors the real BRANCH_ORDER used
   elsewhere in the app (KM..HQ — SDK is a hidden/legacy branch and is
   deliberately left out, same as it's excluded from Branch Performance
   everywhere else). ENTITY_BRANCHES are the three additional outlets that
   don't earn sales commission and have no SR/BM roster of their own — every
   person tracked there is added directly on this page via "Add Staff". ── */
const RETAIL_BRANCHES=["KM","T1","TW2","TW1","LD","KB","T5","ITCC","TENOM","HQ"];
const ENTITY_BRANCHES=["DOJO","MINI_IMPIAN","ESPACE"];
const BRANCHES=[...RETAIL_BRANCHES,...ENTITY_BRANCHES];
const ENTITY_BRANCH_META={
  DOJO:{name:"Dojo Papar",group:"entity"},
  MINI_IMPIAN:{name:"Mini Impian",group:"entity"},
  ESPACE:{name:"Espace",group:"entity"},
};
const isEntityBranch=(b,meta)=>meta[b]?.group==="entity";
// HQ stays a real retail/commission branch everywhere else in the app (its
// actual commission/target calculations are untouched) and still shows its
// normal Business Hours / lateness tracking here — but per Sophia's request
// the Attendance page itself shows no payout %/column for HQ, same as the
// entity outlets. Scoped to this display only, so it's kept separate from
// isEntityBranch rather than folded into it.
const NO_PAYOUT_BRANCHES=["HQ"];
const hidesPayout=(b,meta)=>isEntityBranch(b,meta)||NO_PAYOUT_BRANCHES.includes(b);

const ATTENDANCE_HOURS_KEY="emax_v5_business_hours";
const ATTENDANCE_EXTRA_STAFF_KEY="emax_v5_attendance_extra_staff";
const attendanceKeyFor=(year,month)=>`emax_v5_attendance_${year}_${month}`;
const seedBusinessHours=()=>Object.fromEntries(BRANCHES.map(b=>[b,{start:"09:30",end:"18:30"}]));

const [FIRST_YEAR,FIRST_MONTH]=[2026,10]; // October 2026 — data starts here, month picker won't go earlier
const MONTH_NAMES=["","January","February","March","April","May","June","July","August","September","October","November","December"];
const daysInMonth=(y,m)=>new Date(y,m,0).getDate();
const minutesOf=t=>{if(!t)return null;const[h,m]=t.split(":").map(Number);return h*60+m;};
const fmtMinutes=n=>{const h=Math.floor(n/60),m=n%60;return h>0?`${h}h ${m}m`:`${m}m`;};

/* ── Identity: a person who is Branch Manager of more than one branch
   (e.g. SUHAIDI at Emax CKS and Emax ITCC) is the same real person, tied
   together for display via the same managerId field branchMeta[branch]
   .managerId already carries (the same field the just-shipped BM-identity
   fix uses for reward/ranking). Falls back to matching the manager NAME
   when one side hasn't had a managerId set yet, so this still behaves
   sensibly on data that predates that field being filled in everywhere. ── */
function otherBranchesManagedBy(branch,meta){
  const m=meta[branch]||{};
  if(!m.manager)return[];
  return RETAIL_BRANCHES.filter(b=>{
    if(b===branch)return false;
    const m2=meta[b]||{};
    if(!m2.manager)return false;
    if(m.managerId&&m2.managerId)return m.managerId===m2.managerId;
    return m.manager===m2.manager;
  });
}
// HQ is a retail/commission branch everywhere else in the app (payout,
// targets, branch grouping all stay untouched), but per Sophia's explicit
// request its Attendance roster is NOT auto-populated from branchMeta's
// manager or from srList — it starts empty, same as the manual-add-only
// entity outlets, and staff only appear once Sophia/emaxhr add them via
// "Add Staff". This is purely a roster-population rule, so it lives here
// rather than in isEntityBranch (which still governs payout display and
// must keep treating HQ as a normal commission branch).
const MANUAL_ROSTER_ONLY_BRANCHES=["HQ"];
// Attendance records themselves stay per-branch (like employment/status
// history does) — a manager can have different hours/history at each
// branch they run — keyed BM_<branch>, never by managerId. Identity is
// only shared for DISPLAY (the "Also manages" note), not for the record.
function rosterFor(branch,meta,srList){
  if(MANUAL_ROSTER_ONLY_BRANCHES.includes(branch))return[];
  const m=meta[branch]||{};
  const people=[];
  if(m.manager)people.push({id:`BM_${branch}`,name:m.manager,role:"Branch Manager",branch,alsoManages:otherBranchesManagedBy(branch,meta)});
  srList.filter(s=>s.branch===branch).forEach(s=>people.push({id:s.id,name:s.canon,role:`${s.type} SR`,branch}));
  return people;
}
function combinedRoster(branch,meta,srList,extraStaff){
  return[...rosterFor(branch,meta,srList),...(extraStaff[branch]||[])];
}

/* ── Lateness / early-out / leave / payout logic (unchanged from preview) ── */
const GRACE_MINUTES=10;
function dayStatus(entry,hours){
  if(!entry)return{filled:false};
  if(entry.leave){
    const meta=leaveMeta(entry.leave);
    return{filled:true,isLeave:true,leaveCode:entry.leave,leaveLabel:meta?meta.label:entry.leave,isLate:false,isEarlyOut:false,isIssue:false};
  }
  if(!entry.in)return{filled:false};
  const inM=minutesOf(entry.in),startM=minutesOf(hours.start),endM=minutesOf(hours.end);
  const lateBy=inM-startM;
  const isLate=lateBy>GRACE_MINUTES;
  const outM=entry.out?minutesOf(entry.out):null;
  const isEarlyOut=outM!==null&&outM<endM;
  const isIssue=isLate||isEarlyOut;
  return{filled:true,isLeave:false,isLate,lateBy:isLate?lateBy:0,isEarlyOut,earlyBy:isEarlyOut?endM-outM:0,isIssue};
}
function monthStatsFor(personId,attendance,hours,year,month){
  const days=daysInMonth(year,month);
  let present=0,late=0,earlyOut=0,issues=0,notFilled=0,leaveDays=0;
  for(let d=1;d<=days;d++){
    const st=dayStatus(attendance[personId]?.[d],hours);
    if(!st.filled){notFilled++;continue;}
    if(st.isLeave){
      if(HALF_DAY_LEAVE_CODES.includes(st.leaveCode)){leaveDays+=0.5;present+=0.5;}
      else leaveDays++;
      continue;
    }
    present++;
    if(st.isLate)late++;
    if(st.isEarlyOut)earlyOut++;
    if(st.isIssue)issues++;
  }
  return{present,late,earlyOut,issues,notFilled,leaveDays};
}
function leaveBreakdownFor(personId,attendance,year,month){
  const days=daysInMonth(year,month);
  const counts={AL:0,AH:0,SL:0,RL:0,UL:0,UH:0,OFF:0,PH:0};
  for(let d=1;d<=days;d++){
    const entry=attendance[personId]?.[d];
    if(entry&&entry.leave&&counts[entry.leave]!==undefined)counts[entry.leave]++;
  }
  return counts;
}
function payoutPctFor(issueCount){
  if(issueCount>=3)return 0;
  if(issueCount===2)return 50;
  if(issueCount===1)return 80;
  return 100;
}
const payoutColor=pct=>pct===100?C.green:pct===80?C.amber:pct===50?"#C2410C":C.red;

/* ── Branch/outlet picker — row of pill buttons, grouped Retail vs Other
   Outlets, instead of a dropdown. ─────────────────────────────────────── */
function BranchTabs({value,onChange,meta}){
  const rowStyle={display:"flex",flexWrap:"wrap",gap:6};
  const btnStyle=b=>({padding:"6px 13px",borderRadius:20,border:`1px solid ${value===b?C.navy:C.border}`,background:value===b?C.navy:"#fff",color:value===b?"#fff":C.textMid,fontSize:11.5,fontWeight:700,cursor:"pointer",fontFamily:"Inter,sans-serif",whiteSpace:"nowrap"});
  return<div style={{display:"flex",flexDirection:"column",gap:10}}>
    <div>
      <div style={{fontSize:9.5,fontWeight:700,color:C.textLight,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:6}}>Retail Branches</div>
      <div style={rowStyle}>{RETAIL_BRANCHES.map(b=><button key={b} onClick={()=>onChange(b)} style={btnStyle(b)}>{meta[b]?.name||b}</button>)}</div>
    </div>
    <div>
      <div style={{fontSize:9.5,fontWeight:700,color:C.textLight,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:6}}>Other Outlets</div>
      <div style={rowStyle}>{ENTITY_BRANCHES.map(b=><button key={b} onClick={()=>onChange(b)} style={btnStyle(b)}>{meta[b]?.name||b}</button>)}</div>
    </div>
  </div>;
}

/* ── Add Staff modal — attendance-record only, not tied to the monthly
   commission/report roster (srList) kept elsewhere. ─────────────────── */
function AddStaffModal({branch,meta,onAdd,onClose}){
  const[name,setName]=useState("");
  const[role,setRole]=useState("");
  const canSave=name.trim()&&role.trim();
  return<div style={{position:"fixed",inset:0,background:"rgba(10,22,40,.65)",backdropFilter:"blur(4px)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
    <div style={{...card,width:"90%",maxWidth:380}}>
      <div style={{background:`linear-gradient(135deg,${C.navy},${C.navyLight})`,padding:"14px 18px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{fontWeight:800,fontSize:13,color:"#fff"}}>Add Staff — {meta[branch]?.name||branch}</div>
        <button onClick={onClose} style={{background:"rgba(255,255,255,.1)",border:"1px solid rgba(255,255,255,.2)",color:"rgba(255,255,255,.7)",borderRadius:7,padding:"4px 10px",cursor:"pointer"}}>×</button>
      </div>
      <div style={{padding:18}}>
        <div style={{marginBottom:12}}><L req>Name</L><I value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. JASON LIM"/></div>
        <div style={{marginBottom:14}}><L req>Role</L><I value={role} onChange={e=>setRole(e.target.value)} placeholder="e.g. Offline SR, Instructor..."/></div>
        <div style={{fontSize:10.5,color:C.textLight,background:C.surface,border:`1px solid ${C.border}`,borderRadius:6,padding:"7px 10px",marginBottom:14}}>Added here for attendance tracking only — this does not add them to the monthly commission/report roster kept elsewhere.</div>
        <div style={{display:"flex",gap:8}}>
          <PBtn disabled={!canSave} onClick={()=>{onAdd({id:`extra_${branch}_${Date.now()}`,name:name.trim(),role:role.trim(),branch});onClose();}} style={{flex:1}}>{Ic.check} Add Staff</PBtn>
          <GBtn onClick={onClose}>Cancel</GBtn>
        </div>
      </div>
    </div>
  </div>;
}

/* ── Clock-in/out (or leave) edit modal (emaxhr / Sophia fills this in) ── */
function DayEditModal({person,day,monthLabel,entry,hours,onSave,onClose}){
  const[type,setType]=useState(entry?.leave?entry.leave:"WORKED");
  const[inT,setInT]=useState(entry?.in||"");
  const[outT,setOutT]=useState(entry?.out||"");
  const preview=type==="WORKED"?dayStatus({in:inT,out:outT},hours):null;
  const canSave=type==="WORKED"?!!inT:true;
  const handleSave=()=>{
    if(type==="WORKED")onSave(day,{in:inT,out:outT||null});
    else onSave(day,{leave:type});
    onClose();
  };
  return<div style={{position:"fixed",inset:0,background:"rgba(10,22,40,.65)",backdropFilter:"blur(4px)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
    <div style={{...card,width:"90%",maxWidth:380}}>
      <div style={{background:`linear-gradient(135deg,${C.navy},${C.navyLight})`,padding:"14px 18px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{fontWeight:800,fontSize:13,color:"#fff"}}>{person.name} · Day {day}, {monthLabel}</div>
        <button onClick={onClose} style={{background:"rgba(255,255,255,.1)",border:"1px solid rgba(255,255,255,.2)",color:"rgba(255,255,255,.7)",borderRadius:7,padding:"4px 10px",cursor:"pointer"}}>×</button>
      </div>
      <div style={{padding:18}}>
        <div style={{marginBottom:12}}>
          <L>Day Type</L>
          <SEL value={type} onChange={e=>setType(e.target.value)}>
            <option value="WORKED">Worked (clock in / out)</option>
            {LEAVE_TYPES.map(l=><option key={l.code} value={l.code}>{l.label}</option>)}
          </SEL>
        </div>
        {type==="WORKED"?<>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:12}}>
            <div><L req>Clock In</L><I type="time" value={inT} onChange={e=>setInT(e.target.value)}/></div>
            <div><L>Clock Out</L><I type="time" value={outT} onChange={e=>setOutT(e.target.value)}/></div>
          </div>
          <div style={{fontSize:11,color:C.textLight,marginBottom:12}}>Business Hours: {hours.start} – {hours.end} · grace {GRACE_MINUTES} min</div>
          {preview.filled&&<div style={{display:"flex",flexDirection:"column",gap:6,marginBottom:14}}>
            {preview.isLate
              ?<div style={{fontSize:11,fontWeight:700,color:C.red,background:"#FEF2F2",border:"1px solid #FECACA",borderRadius:6,padding:"6px 10px"}}>Late by {fmtMinutes(preview.lateBy)}</div>
              :<div style={{fontSize:11,fontWeight:700,color:C.green,background:"#F0FDF4",border:"1px solid #BBF7D0",borderRadius:6,padding:"6px 10px"}}>On time</div>}
            {preview.isEarlyOut&&<div style={{fontSize:11,fontWeight:700,color:C.amber,background:"#FFFBEB",border:"1px solid #FDE68A",borderRadius:6,padding:"6px 10px"}}>Early Out by {fmtMinutes(preview.earlyBy)}</div>}
          </div>}
        </>:<div style={{fontSize:11.5,fontWeight:600,color:leaveMeta(type).color,background:leaveMeta(type).color+"12",border:`1px solid ${leaveMeta(type).color}40`,borderRadius:6,padding:"8px 10px",marginBottom:14}}>Marked as {leaveMeta(type).label} — no clock-in/out needed. Never counted as late, early-out, or an issue, and won't reduce commission payout.</div>}
        <div style={{display:"flex",gap:8}}>
          <PBtn disabled={!canSave} onClick={handleSave} style={{flex:1}}>{Ic.check} Save</PBtn>
          {entry&&<GBtn onClick={()=>{onSave(day,null);onClose();}}>Clear</GBtn>}
          <GBtn onClick={onClose}>Cancel</GBtn>
        </div>
      </div>
    </div>
  </div>;
}

/* ── Small legend for the day-grid colors, shown under each roster ──── */
function DayLegend(){
  return<div style={{display:"flex",gap:8,flexWrap:"wrap",fontSize:10,color:C.textLight,marginTop:10,paddingTop:10,borderTop:`1px dashed ${C.border}`}}>
    <span style={{display:"flex",alignItems:"center",gap:4}}><span style={{width:9,height:9,borderRadius:3,background:"#F0FDF4",border:"1px solid #BBF7D0"}}/>On time</span>
    <span style={{display:"flex",alignItems:"center",gap:4}}><span style={{width:9,height:9,borderRadius:3,background:"#FEF2F2",border:"1px solid #FECACA"}}/>Issue (late/early out)</span>
    {LEAVE_TYPES.map(l=><span key={l.code} style={{display:"flex",alignItems:"center",gap:4}}><span style={{width:9,height:9,borderRadius:3,background:l.color+"18",border:`1px solid ${l.color}55`}}/>{l.code} = {l.label}</span>)}
  </div>;
}

/* ── Fill-in table: staff down the side, one column per day — the same
   shape as the monthly report table (emaxhr / Sophia only). ─────────── */
function HRFillInView({year,month,meta,srList,attendance,setAttendance,hours,extraStaff,onAddStaff,branch,setBranch}){
  const[editing,setEditing]=useState(null); // {person, day}
  const[adding,setAdding]=useState(false);
  const roster=combinedRoster(branch,meta,srList,extraStaff);
  const days=daysInMonth(year,month);
  const dayList=Array.from({length:days},(_,i)=>i+1);
  const monthLabel=`${MONTH_NAMES[month]} ${year}`;
  const branchHours=hours[branch]||{start:"09:30",end:"18:30"};

  const saveDay=(personId,day,entry)=>{
    setAttendance(prev=>{
      const personRec={...(prev[personId]||{})};
      if(entry===null)delete personRec[day];
      else personRec[day]=entry;
      return{...prev,[personId]:personRec};
    });
  };

  const thStyle={padding:"7px 6px",fontSize:9.5,fontWeight:700,color:"rgba(255,255,255,.8)",textTransform:"uppercase",letterSpacing:"0.04em",textAlign:"center",whiteSpace:"nowrap"};
  const tdBase={padding:0,textAlign:"center",borderBottom:`1px solid ${C.border}`,borderRight:`1px solid ${C.border}`};

  return<div>
    <div style={{marginBottom:14}}><BranchTabs value={branch} onChange={setBranch} meta={meta}/></div>
    <div style={{display:"flex",gap:10,marginBottom:14,flexWrap:"wrap",alignItems:"center"}}>
      <div style={{fontSize:11,color:C.textLight}}>{isEntityBranch(branch,meta)?"No lateness rule shown for outlets by default.":<>Business Hours: <b style={{color:C.text}}>{branchHours.start} – {branchHours.end}</b></>}</div>
      <div style={{flex:1}}/>
      <GBtn onClick={()=>setAdding(true)}>{Ic.plus} Add Staff</GBtn>
    </div>

    {roster.length===0?<div style={{...card,padding:24,textAlign:"center",fontSize:12,color:C.textLight}}>No staff yet for {meta[branch]?.name||branch}. Use "Add Staff" above to start tracking attendance here.</div>:
    <div style={{...card,overflowX:"auto"}}>
      <table style={{borderCollapse:"collapse",width:"100%",fontFamily:"Inter,sans-serif"}}>
        <thead>
          <tr style={{background:`linear-gradient(135deg,${C.navy},${C.navyLight})`}}>
            <th style={{...thStyle,position:"sticky",left:0,background:C.navy,textAlign:"left",padding:"7px 10px",minWidth:150,zIndex:2}}>Staff</th>
            {dayList.map(d=><th key={d} style={{...thStyle,minWidth:28}}>{d}</th>)}
            <th style={{...thStyle,minWidth:52}}>Issues</th>
            <th style={{...thStyle,minWidth:52}}>Leave</th>
            <th style={{...thStyle,minWidth:64}}>Payout</th>
          </tr>
        </thead>
        <tbody>
          {roster.map((person,ri)=>{
            const stats=monthStatsFor(person.id,attendance,branchHours,year,month);
            const pct=payoutPctFor(stats.issues);
            const rowBg=ri%2===0?"#fff":C.surface;
            return<tr key={person.id}>
              <td style={{...tdBase,position:"sticky",left:0,background:rowBg,textAlign:"left",padding:"8px 10px",zIndex:1}}>
                <div style={{fontWeight:700,fontSize:12,color:C.text}}>{person.name}</div>
                <div style={{fontSize:10,color:C.textLight}}>{person.role}</div>
                {person.alsoManages?.length>0&&<div style={{fontSize:9,color:C.blueBright,marginTop:1}}>Also at: {person.alsoManages.map(b=>meta[b]?.name||b).join(", ")}</div>}
              </td>
              {dayList.map(d=>{
                const entry=attendance[person.id]?.[d];
                const st=dayStatus(entry,branchHours);
                let bg=rowBg,fg=C.textLight,label="·";
                if(st.filled&&st.isLeave){const m=leaveMeta(st.leaveCode);bg=m.color+"18";fg=m.color;label=st.leaveCode;}
                else if(st.filled&&st.isIssue){bg="#FEF2F2";fg=C.red;label="!";}
                else if(st.filled){bg="#F0FDF4";fg=C.green;label="✓";}
                const title=st.filled?(st.isLeave?st.leaveLabel:`${entry.in} – ${entry.out||"—"}`):"Not filled — click to fill in";
                return<td key={d} style={{...tdBase,background:bg}}>
                  <button onClick={()=>setEditing({person,day:d})} title={title} style={{width:"100%",height:30,border:"none",background:"transparent",color:fg,fontSize:st.isLeave?9:11,fontWeight:700,cursor:"pointer"}}>{label}</button>
                </td>;
              })}
              <td style={{...tdBase,background:rowBg,fontSize:12,fontWeight:700,color:stats.issues>0?C.red:C.textLight}}>{stats.issues}</td>
              <td style={{...tdBase,background:rowBg,fontSize:12,color:C.textMid}}>{stats.leaveDays}</td>
              <td style={{...tdBase,background:rowBg,borderRight:"none"}}>{hidesPayout(branch,meta)?<span style={{fontSize:11,color:C.textLight}}>—</span>:<span style={{fontSize:11,fontWeight:800,color:payoutColor(pct),background:payoutColor(pct)+"15",padding:"3px 9px",borderRadius:20,display:"inline-block"}}>{pct}%</span>}</td>
            </tr>;
          })}
        </tbody>
      </table>
    </div>}
    <DayLegend/>

    {editing&&<DayEditModal person={editing.person} day={editing.day} monthLabel={monthLabel} entry={attendance[editing.person.id]?.[editing.day]} hours={branchHours}
      onSave={(day,entry)=>saveDay(editing.person.id,day,entry)} onClose={()=>setEditing(null)}/>}
    {adding&&<AddStaffModal branch={branch} meta={meta} onAdd={p=>onAddStaff(branch,p)} onClose={()=>setAdding(false)}/>}
  </div>;
}

/* ── Sophia-only: edit each branch's Business Hours + add staff ──────── */
function BusinessHoursView({meta,hours,setHours,extraStaff,onAddStaff}){
  const[draft,setDraft]=useState(hours);
  const[addingFor,setAddingFor]=useState(null);
  useEffect(()=>{setDraft(hours);},[hours]);
  const dirty=JSON.stringify(draft)!==JSON.stringify(hours);
  const renderCard=b=><div key={b} style={{...card,padding:14}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
      <div style={{fontWeight:700,fontSize:12.5,color:C.text}}>{meta[b]?.name||b}</div>
      <button onClick={()=>setAddingFor(b)} title="Add staff (attendance only)" style={{background:"transparent",border:`1px solid ${C.border}`,borderRadius:6,padding:"3px 7px",cursor:"pointer",color:C.textMid,display:"flex",alignItems:"center"}}>{Ic.plus}</button>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:8}}>
      <div><L>Clock In</L><I type="time" value={draft[b]?.start||"09:30"} onChange={e=>setDraft(p=>({...p,[b]:{...p[b],start:e.target.value}}))}/></div>
      <div><L>Clock Out</L><I type="time" value={draft[b]?.end||"18:30"} onChange={e=>setDraft(p=>({...p,[b]:{...p[b],end:e.target.value}}))}/></div>
    </div>
    {(extraStaff[b]||[]).length>0&&<div style={{fontSize:10,color:C.textLight}}>+{extraStaff[b].length} added here: {extraStaff[b].map(s=>s.name).join(", ")}</div>}
  </div>;
  return<div>
    <div style={{fontSize:10.5,fontWeight:700,color:C.textLight,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:8}}>Retail Branches</div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:12,marginBottom:20}}>
      {RETAIL_BRANCHES.map(renderCard)}
    </div>
    <div style={{fontSize:10.5,fontWeight:700,color:C.textLight,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:8}}>Other Outlets</div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:12,marginBottom:16}}>
      {ENTITY_BRANCHES.map(renderCard)}
    </div>
    <PBtn disabled={!dirty} onClick={()=>setHours(draft)}>{Ic.check} Save Business Hours</PBtn>
    {addingFor&&<AddStaffModal branch={addingFor} meta={meta} onAdd={p=>onAddStaff(addingFor,p)} onClose={()=>setAddingFor(null)}/>}
  </div>;
}

/* ── Attendance Summary — same shape as the Attendance Table, with a
   Working Days column plus one column per leave type. UPL combines
   full-day Unpaid Leave (UL) with half-day Unpaid Leave (UH) at 0.5. ──── */
function AttendanceSummaryTable({year,month,meta,srList,attendance,hours,extraStaff,branch,setBranch}){
  const roster=combinedRoster(branch,meta,srList,extraStaff);
  const branchHours=hours[branch]||{start:"09:30",end:"18:30"};
  const fmt=n=>Number.isInteger(n)?n:n.toFixed(1);
  const thStyle={padding:"7px 8px",fontSize:9.5,fontWeight:700,color:"rgba(255,255,255,.8)",textTransform:"uppercase",letterSpacing:"0.04em",textAlign:"center",whiteSpace:"nowrap"};
  const tdBase={padding:"8px",textAlign:"center",borderBottom:`1px solid ${C.border}`,borderRight:`1px solid ${C.border}`,fontSize:12,color:C.textMid};

  return<div>
    <div style={{marginBottom:14}}><BranchTabs value={branch} onChange={setBranch} meta={meta}/></div>
    {roster.length===0?<div style={{...card,padding:24,textAlign:"center",fontSize:12,color:C.textLight}}>No staff yet for {meta[branch]?.name||branch}.</div>:
    <div style={{...card,overflowX:"auto"}}>
      <table style={{borderCollapse:"collapse",width:"100%",fontFamily:"Inter,sans-serif"}}>
        <thead>
          <tr style={{background:`linear-gradient(135deg,${C.navy},${C.navyLight})`}}>
            <th style={{...thStyle,position:"sticky",left:0,background:C.navy,textAlign:"left",padding:"7px 10px",minWidth:150,zIndex:2}}>Staff</th>
            <th style={{...thStyle,minWidth:70}}>Working Days</th>
            <th style={{...thStyle,minWidth:56}}>AL</th>
            <th style={{...thStyle,minWidth:56}}>SL</th>
            <th style={{...thStyle,minWidth:56}}>RL</th>
            <th style={{...thStyle,minWidth:56}}>UPL</th>
            <th style={{...thStyle,minWidth:56}}>Off</th>
            <th style={{...thStyle,minWidth:56}}>PH</th>
          </tr>
        </thead>
        <tbody>
          {roster.map((person,ri)=>{
            const stats=monthStatsFor(person.id,attendance,branchHours,year,month);
            const c=leaveBreakdownFor(person.id,attendance,year,month);
            const al=c.AL+0.5*c.AH;
            const upl=c.UL+0.5*c.UH;
            const rowBg=ri%2===0?"#fff":C.surface;
            return<tr key={person.id}>
              <td style={{...tdBase,position:"sticky",left:0,background:rowBg,textAlign:"left",zIndex:1}}>
                <div style={{fontWeight:700,fontSize:12,color:C.text}}>{person.name}</div>
                <div style={{fontSize:10,color:C.textLight}}>{person.role}</div>
                {person.alsoManages?.length>0&&<div style={{fontSize:9,color:C.blueBright,marginTop:1}}>Also at: {person.alsoManages.map(b=>meta[b]?.name||b).join(", ")}</div>}
              </td>
              <td style={{...tdBase,background:rowBg,fontWeight:800,color:C.text}}>{fmt(stats.present)}</td>
              <td style={{...tdBase,background:rowBg,color:al>0?leaveMeta("AL").color:C.textLight,fontWeight:al>0?700:400}}>{fmt(al)}</td>
              <td style={{...tdBase,background:rowBg,color:c.SL>0?leaveMeta("SL").color:C.textLight,fontWeight:c.SL>0?700:400}}>{c.SL}</td>
              <td style={{...tdBase,background:rowBg,color:c.RL>0?leaveMeta("RL").color:C.textLight,fontWeight:c.RL>0?700:400}}>{c.RL}</td>
              <td style={{...tdBase,background:rowBg,color:upl>0?leaveMeta("UL").color:C.textLight,fontWeight:upl>0?700:400}}>{fmt(upl)}</td>
              <td style={{...tdBase,background:rowBg,color:c.OFF>0?leaveMeta("OFF").color:C.textLight,fontWeight:c.OFF>0?700:400}}>{c.OFF}</td>
              <td style={{...tdBase,background:rowBg,borderRight:"none",color:c.PH>0?leaveMeta("PH").color:C.textLight,fontWeight:c.PH>0?700:400}}>{c.PH}</td>
            </tr>;
          })}
        </tbody>
      </table>
    </div>}
  </div>;
}

/* ── Read-only day-by-day detail for ONE person. ──────────────────────── */
function PersonAttendanceDetailModal({person,meta,year,month,attendance,hours,onClose}){
  const days=daysInMonth(year,month);
  const dayList=Array.from({length:days},(_,i)=>i+1);
  const stats=monthStatsFor(person.id,attendance,hours,year,month);
  const pct=payoutPctFor(stats.issues);
  const entity=hidesPayout(person.branch,meta);
  return<div style={{position:"fixed",inset:0,background:"rgba(10,22,40,.65)",backdropFilter:"blur(4px)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
    <div style={{...card,width:"95%",maxWidth:520,maxHeight:"85vh",display:"flex",flexDirection:"column"}}>
      <div style={{background:`linear-gradient(135deg,${C.navy},${C.navyLight})`,padding:"14px 18px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontWeight:800,fontSize:14,color:"#fff"}}>{person.name}</div>
          <div style={{fontSize:10.5,color:"rgba(255,255,255,.65)"}}>{person.role} at {meta[person.branch]?.name||person.branch} · {MONTH_NAMES[month]} {year}</div>
          {person.alsoManages?.length>0&&<div style={{fontSize:10,color:"rgba(255,255,255,.55)",marginTop:2}}>Same person also manages: {person.alsoManages.map(b=>meta[b]?.name||b).join(", ")} (separate record there)</div>}
        </div>
        <button onClick={onClose} style={{background:"rgba(255,255,255,.1)",border:"1px solid rgba(255,255,255,.2)",color:"rgba(255,255,255,.7)",borderRadius:7,padding:"4px 10px",cursor:"pointer"}}>×</button>
      </div>
      <div style={{padding:"12px 18px",borderBottom:`1px solid ${C.border}`,display:"flex",gap:16,flexWrap:"wrap",alignItems:"center"}}>
        {entity
          ?<div style={{fontSize:12.5,fontWeight:700,color:C.textMid}}>Attendance Summary <span style={{fontWeight:500,color:C.textLight}}>({stats.issues} late/early-out day{stats.issues===1?"":"s"} this month)</span></div>
          :<>
            <div style={{fontSize:22,fontWeight:800,color:payoutColor(pct)}}>{pct}%</div>
            <div style={{fontSize:10.5,color:C.textLight}}>Commission Payout<br/>({stats.issues} issue{stats.issues===1?"":"s"} this month)</div>
          </>}
        <div style={{flex:1}}/>
        <div style={{fontSize:11,color:C.textMid}}>Present: <b>{stats.present}</b> · Leave/Off: <b>{stats.leaveDays}</b> · Not filled: <b>{stats.notFilled}</b></div>
      </div>
      <div style={{overflowY:"auto",padding:"0 18px"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:11.5}}>
          <thead><tr style={{position:"sticky",top:0,background:"#fff"}}>
            <th style={{textAlign:"left",padding:"8px 4px",color:C.textLight,fontSize:10,textTransform:"uppercase",letterSpacing:"0.04em",borderBottom:`1px solid ${C.border}`}}>Day</th>
            <th style={{textAlign:"left",padding:"8px 4px",color:C.textLight,fontSize:10,textTransform:"uppercase",letterSpacing:"0.04em",borderBottom:`1px solid ${C.border}`}}>Clock In</th>
            <th style={{textAlign:"left",padding:"8px 4px",color:C.textLight,fontSize:10,textTransform:"uppercase",letterSpacing:"0.04em",borderBottom:`1px solid ${C.border}`}}>Clock Out</th>
            <th style={{textAlign:"left",padding:"8px 4px",color:C.textLight,fontSize:10,textTransform:"uppercase",letterSpacing:"0.04em",borderBottom:`1px solid ${C.border}`}}>Status (as filled by emaxhr)</th>
          </tr></thead>
          <tbody>
            {dayList.map(d=>{
              const entry=attendance[person.id]?.[d];
              const st=dayStatus(entry,hours);
              let statusEl;
              if(!st.filled)statusEl=<span style={{color:C.textLight}}>Not filled</span>;
              else if(st.isLeave)statusEl=<span style={{color:leaveMeta(st.leaveCode).color,fontWeight:700}}>{st.leaveLabel}</span>;
              else if(st.isLate&&st.isEarlyOut)statusEl=<span style={{color:C.red,fontWeight:700}}>Late {fmtMinutes(st.lateBy)} + Early Out {fmtMinutes(st.earlyBy)}</span>;
              else if(st.isLate)statusEl=<span style={{color:C.red,fontWeight:700}}>Late by {fmtMinutes(st.lateBy)}</span>;
              else if(st.isEarlyOut)statusEl=<span style={{color:C.amber,fontWeight:700}}>Early Out by {fmtMinutes(st.earlyBy)}</span>;
              else statusEl=<span style={{color:C.green,fontWeight:700}}>On time</span>;
              return<tr key={d} style={{background:st.filled&&st.isIssue?"#FEF2F2":"transparent"}}>
                <td style={{padding:"6px 4px",borderBottom:`1px solid ${C.border}`,color:C.text,fontWeight:700}}>{d}</td>
                <td style={{padding:"6px 4px",borderBottom:`1px solid ${C.border}`,color:C.textMid}}>{st.filled&&!st.isLeave?entry.in:"—"}</td>
                <td style={{padding:"6px 4px",borderBottom:`1px solid ${C.border}`,color:C.textMid}}>{st.filled&&!st.isLeave?(entry.out||"—"):"—"}</td>
                <td style={{padding:"6px 4px",borderBottom:`1px solid ${C.border}`}}>{statusEl}</td>
              </tr>;
            })}
          </tbody>
        </table>
      </div>
      <div style={{padding:"12px 18px"}}><GBtn onClick={onClose} style={{width:"100%",justifyContent:"center"}}>Close</GBtn></div>
    </div>
  </div>;
}

/* ── Read-only branch view — one branch's roster + payout %. Used both by
   a real branch account (locked to its own branch — no selector) and by
   Boon Theng/Wingfei (selector shown, browsing every branch/outlet). ──── */
function BranchView({year,month,meta,srList,attendance,hours,extraStaff,allowBranchSwitch,branch,setBranch}){
  const[viewing,setViewing]=useState(null); // person
  const roster=combinedRoster(branch,meta,srList,extraStaff);
  const branchHours=hours[branch]||{start:"09:30",end:"18:30"};
  const entity=hidesPayout(branch,meta);
  return<div>
    {allowBranchSwitch
      ?<div style={{marginBottom:16}}><BranchTabs value={branch} onChange={setBranch} meta={meta}/></div>
      :null}
    <div style={{fontSize:10.5,color:C.textLight,marginBottom:12}}>Click a card to see the exact clock-in/out (or leave) emaxhr recorded for every day.</div>
    {roster.length===0?<div style={{...card,padding:24,textAlign:"center",fontSize:12,color:C.textLight}}>No attendance records yet for {meta[branch]?.name||branch}.</div>:
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:14}}>
      {roster.map(person=>{
        const stats=monthStatsFor(person.id,attendance,branchHours,year,month);
        const pct=payoutPctFor(stats.issues);
        return<div key={person.id} onClick={()=>setViewing(person)} style={{...card,padding:16,cursor:"pointer"}}>
          <div style={{fontWeight:700,fontSize:14,color:C.text}}>{person.name}</div>
          <div style={{fontSize:11,color:C.textLight,marginBottom:person.alsoManages?.length>0?2:12}}>{person.role}</div>
          {person.alsoManages?.length>0&&<div style={{fontSize:9.5,color:C.blueBright,marginBottom:10}}>Also manages: {person.alsoManages.map(b=>meta[b]?.name||b).join(", ")}</div>}
          {entity
            ?<div style={{fontSize:11,fontWeight:700,color:C.textMid,textTransform:"uppercase",letterSpacing:"0.04em",marginBottom:10}}>Attendance Summary</div>
            :<>
              <div style={{fontSize:26,fontWeight:800,color:payoutColor(pct),lineHeight:1}}>{pct}%</div>
              <div style={{fontSize:10.5,color:C.textLight,marginBottom:12}}>Commission Payout</div>
            </>}
          <div style={{display:"flex",gap:10,fontSize:11,color:C.textMid,flexWrap:"wrap"}}>
            <span>Present: <b style={{color:C.text}}>{stats.present}</b></span>
            <span style={{color:stats.late>0?C.red:C.textMid}}>Late: <b>{stats.late}</b></span>
            <span style={{color:stats.earlyOut>0?C.amber:C.textMid}}>Early Out: <b>{stats.earlyOut}</b></span>
            <span>Leave/Off: <b>{stats.leaveDays}</b></span>
            <span>Not filled: <b>{stats.notFilled}</b></span>
          </div>
          <div style={{fontSize:10,color:C.blueBright,fontWeight:700,marginTop:10}}>View day-by-day record →</div>
        </div>;
      })}
    </div>}
    {viewing&&<PersonAttendanceDetailModal person={viewing} meta={meta} year={year} month={month} attendance={attendance} hours={branchHours} onClose={()=>setViewing(null)}/>}
  </div>;
}

/* ══════════════════════════════════════════════════════════════════════
   Root component — everything else in this file is an implementation
   detail of this one export.
   ══════════════════════════════════════════════════════════════════════ */
export default function AttendanceTab({branchMeta={},srList=[],isAdmin=false,canManageHours=false,userBranch=null,allowBranchSwitch=false,email=null}){
  const meta=useMemo(()=>({...ENTITY_BRANCH_META,...branchMeta}),[branchMeta]);
  const firstBranch=userBranch||RETAIL_BRANCHES[0];

  const [year,setYear]=useState(FIRST_YEAR);
  const [month,setMonth]=useState(FIRST_MONTH);
  const [branch,setBranchRaw]=useState(firstBranch);
  const setBranch=userBranch?()=>{}:setBranchRaw; // locked-branch views never switch
  const effectiveBranch=userBranch||branch;

  const [sub,setSub]=useState(canManageHours?"hours":"table"); // hours | table | summary — admin only

  const [hours,setHours_]=useState(seedBusinessHours());
  const [extraStaff,setExtraStaff_]=useState({});
  const [attendance,setAttendance_]=useState({});
  const [loadingBase,setLoadingBase]=useState(true);
  const [loadingMonth,setLoadingMonth]=useState(true);

  // Business hours + attendance-only staff are month-independent — load once.
  useEffect(()=>{
    let cancelled=false;
    Promise.all([loadData(ATTENDANCE_HOURS_KEY),loadData(ATTENDANCE_EXTRA_STAFF_KEY)]).then(([h,es])=>{
      if(cancelled)return;
      setHours_({...seedBusinessHours(),...(h||{})});
      setExtraStaff_(es||{});
      setLoadingBase(false);
    });
    return()=>{cancelled=true;};
  },[]);

  // Attendance records are per year/month — reload whenever the picker changes.
  useEffect(()=>{
    let cancelled=false;
    setLoadingMonth(true);
    loadData(attendanceKeyFor(year,month)).then(a=>{
      if(cancelled)return;
      setAttendance_(a||{});
      setLoadingMonth(false);
    });
    return()=>{cancelled=true;};
  },[year,month]);

  const setAttendance=updater=>{
    setAttendance_(prev=>{
      const next=typeof updater==="function"?updater(prev):updater;
      saveData(attendanceKeyFor(year,month),next);
      return next;
    });
  };
  const setHours=updater=>{
    setHours_(prev=>{
      const next=typeof updater==="function"?updater(prev):updater;
      saveData(ATTENDANCE_HOURS_KEY,next);
      return next;
    });
  };
  const addStaff=(b,person)=>{
    setExtraStaff_(prev=>{
      const next={...prev,[b]:[...(prev[b]||[]),person]};
      saveData(ATTENDANCE_EXTRA_STAFF_KEY,next);
      return next;
    });
  };

  const monthOptions=[];
  for(let y=FIRST_YEAR;y<=FIRST_YEAR+2;y++){
    for(let m=1;m<=12;m++){
      if(y===FIRST_YEAR&&m<FIRST_MONTH)continue;
      monthOptions.push({y,m});
    }
  }

  if(loadingBase||loadingMonth){
    return<div style={{...card,padding:32,textAlign:"center",fontSize:12,color:C.textLight}}>Loading attendance…</div>;
  }

  return<div>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16,flexWrap:"wrap",gap:10}}>
      <div style={{fontSize:16,fontWeight:800,color:C.navy}}>Attendance</div>
      {isAdmin&&<div style={{display:"flex",gap:6,background:"#fff",border:`1px solid ${C.border}`,borderRadius:9,padding:4,flexWrap:"wrap"}}>
        {canManageHours&&<button onClick={()=>setSub("hours")} style={{padding:"7px 12px",borderRadius:6,border:"none",background:sub==="hours"?C.navy:"transparent",color:sub==="hours"?"#fff":C.textMid,fontSize:11,fontWeight:700,cursor:"pointer",fontFamily:"Inter,sans-serif"}}>Business Hours & Staff</button>}
        <button onClick={()=>setSub("table")} style={{padding:"7px 12px",borderRadius:6,border:"none",background:sub==="table"?C.navy:"transparent",color:sub==="table"?"#fff":C.textMid,fontSize:11,fontWeight:700,cursor:"pointer",fontFamily:"Inter,sans-serif"}}>Attendance Table</button>
        <button onClick={()=>setSub("summary")} style={{padding:"7px 12px",borderRadius:6,border:"none",background:sub==="summary"?C.navy:"transparent",color:sub==="summary"?"#fff":C.textMid,fontSize:11,fontWeight:700,cursor:"pointer",fontFamily:"Inter,sans-serif"}}>Attendance Summary</button>
      </div>}
    </div>

    {(!isAdmin||sub!=="hours")&&<div style={{marginBottom:14,maxWidth:220}}>
      <L>Month</L>
      <SEL value={`${year}-${month}`} onChange={e=>{const[y,m]=e.target.value.split("-").map(Number);setYear(y);setMonth(m);}}>
        {monthOptions.map(o=><option key={`${o.y}-${o.m}`} value={`${o.y}-${o.m}`}>{MONTH_NAMES[o.m]} {o.y}</option>)}
      </SEL>
    </div>}

    {isAdmin?<>
      {sub==="hours"&&canManageHours&&<BusinessHoursView meta={meta} hours={hours} setHours={setHours} extraStaff={extraStaff} onAddStaff={addStaff}/>}
      {sub==="table"&&<HRFillInView year={year} month={month} meta={meta} srList={srList} attendance={attendance} setAttendance={setAttendance} hours={hours} extraStaff={extraStaff} onAddStaff={addStaff} branch={effectiveBranch} setBranch={setBranch}/>}
      {sub==="summary"&&<AttendanceSummaryTable year={year} month={month} meta={meta} srList={srList} attendance={attendance} hours={hours} extraStaff={extraStaff} branch={effectiveBranch} setBranch={setBranch}/>}
    </>:<BranchView year={year} month={month} meta={meta} srList={srList} attendance={attendance} hours={hours} extraStaff={extraStaff} allowBranchSwitch={allowBranchSwitch&&!userBranch} branch={effectiveBranch} setBranch={setBranch}/>}
  </div>;
}
